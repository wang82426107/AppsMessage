//
//  ViewController.m
//  通过程序跳转到iOS设置页面
//
//  Created by songjc on 16/10/8.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (IBAction)openSettingsAction:(id)sender {
    
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"prefs:root=WIFI"]];
    
}



@end
