//
//  ViewController.m
//  从一个程序跳转到另外一个程序
//
//  Created by songjc on 16/10/8.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)openOtherApp:(id)sender {
    
    NSURL *url = [NSURL URLWithString:@"testApp:"];
    
    [[UIApplication sharedApplication] openURL:url];
}

@end
